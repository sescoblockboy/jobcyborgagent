const { chromium } = require('playwright');
const readline = require('readline'); // <-- Added this to read keyboard input
const { profile } = require('./config');
const { generateResumePdf } = require('./pdfGenerator');
const { handleGreenhouse } = require('./ats/greenhouse');
const { handleLever } = require('./ats/lever');

/**
 * Job boards that gate the real employer/ATS link behind their own account
 * creation, login wall, or paid "auto-apply" product. We do NOT attempt to
 * automate account creation or login on these sites.
 *
 * We Work Remotely added an account-registration wall on their "Apply now"
 * button (confirmed Sep 2026) — the listing page no longer exposes the real
 * employer link to logged-out requests. Add new gated domains here as you
 * discover them.
 */
const ACCOUNT_GATED_BOARDS = [
  { hostSuffix: 'weworkremotely.com', reason: 'WWR requires account creation to reveal employer link' },
];

function findGatedBoard(url) {
  let hostname;
  try {
    hostname = new URL(url).hostname.toLowerCase();
  } catch {
    return null;
  }
  return ACCOUNT_GATED_BOARDS.find(
    ({ hostSuffix }) => hostname === hostSuffix || hostname.endsWith('.' + hostSuffix)
  ) || null;
}

// Creates a terminal prompt so the agent pauses for your permission
function askUserApproval(promptText) {
  const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
  });
  return new Promise(resolve => {
    rl.question(promptText, answer => {
      rl.close();
      resolve(answer.trim().toLowerCase());
    });
  });
}

/**
 * Pauses for human review, then attempts to click the submit button.
 */
async function autoSubmit(page) {
  console.log('\n======================================================');
  console.log('✅ Form populated. Please inspect the open browser window.');
  console.log('Commands:');
  console.log('  [y] Looks good! Submit form automatically');
  console.log('  [m] I already clicked submit manually');
  console.log('  [s] Skip / Cancel this application');
  console.log('======================================================\n');

  const decision = await askUserApproval('Enter decision [y/m/s]: ');

  if (decision === 'y') {
    const submitBtn = await page.$('button[type="submit"], input[type="submit"], #submit_app');
    if (!submitBtn) {
      return { submitted: false, reason: 'Submit button not found' };
    }
    
    const urlBeforeClick = page.url();
    await submitBtn.click();
    
    // Give the page a few seconds to react or throw validation errors
    await page.waitForTimeout(5000);
    
    // Check if red validation errors popped up on the page
    const hasErrors = await page.$('.field-error, .error-message, [aria-invalid="true"], .has-error');
    const urlAfterClick = page.url();

    if (hasErrors && urlBeforeClick === urlAfterClick) {
      console.warn('⚠️ Validation errors detected! The form turned red and blocked submission.');
      console.log('Please fix the red fields manually in the browser, then press [m] in the terminal.');
      
      // Give you a chance to fix it manually instead of closing!
      const manualRescue = await askUserApproval('Did you fix and submit it manually now? Enter [m] to finish or [s] to abort: ');
      if (manualRescue === 'm') {
        return { submitted: true };
      }
      return { submitted: false, reason: 'Form validation failed and boxes turned red' };
    }

    return { submitted: true };
  } else if (decision === 'm') {
    return { submitted: true }; 
  } else {
    return { submitted: false, reason: 'Application aborted by user' };
  }
}
async function runApplicationPipeline(jobData) {
  const { rowId, applyUrl, resumeMarkdown, coverLetter } = jobData;

  // NEW: Resume Data Check to catch the empty PDF bug
  console.log('\n--- RESUME DATA CHECK ---');
  console.log(resumeMarkdown ? `Received ${resumeMarkdown.length} characters of resume text.` : 'WARNING: Resume text is EMPTY!');
  console.log('-------------------------\n');

  console.log(`\n--- Starting Job Application for Row #${rowId} ---`);
  console.log(`URL: ${applyUrl}`);

  // 1. Generate Local PDF Resume — always do this first, even for gated
  //    boards, so a human can apply manually within seconds.
  const resumePdfPath = await generateResumePdf(resumeMarkdown, rowId);
  console.log(`Generated tailored PDF: ${resumePdfPath}`);

  // 2. Short-circuit account-gated boards before touching a browser at all.
  const gated = findGatedBoard(applyUrl);
  if (gated) {
    console.log(`Skipping automation: ${gated.reason}.`);
    return {
      status: 'Needs Human Input',
      reason: gated.reason,
      rowId,
      resumePdfPath
    };
  }

  // 3. Launch Visible Desktop Browser
  const browser = await chromium.launch({
    headless: false,
    slowMo: 50
  });

  const context = await browser.newContext();
  const page = await context.newPage();

  try {
    await page.goto(applyUrl, { waitUntil: 'domcontentloaded', timeout: 30000 });

    // 4. Scan for CAPTCHAs
    const hasCaptcha = await page.$('iframe[src*="captcha"], iframe[src*="turnstile"], div.g-recaptcha');
    if (hasCaptcha) {
      console.warn('⚠️ CAPTCHA detected. Halting for user intervention.');
      return { status: 'CAPTCHA', rowId, resumePdfPath };
    }

    // 5. Platform Routing
    const currentUrl = page.url();

    if (currentUrl.includes('greenhouse.io') || await page.$('#application_form')) {
      console.log('Target identified: Greenhouse — filling form...');
      await handleGreenhouse(page, profile, resumePdfPath, coverLetter);

      // Now it will pause and ask for y/m/s before submitting!
      const { submitted, reason } = await autoSubmit(page);
      if (submitted) {
        return { status: 'Applied', rowId, resumePdfPath };
      }
      console.warn(`Could not auto-submit: ${reason}`);
      return { status: 'Needs Human Input', reason, rowId, resumePdfPath };

    } else if (currentUrl.includes('lever.co') || await page.$('.application-form')) {
      console.log('Target identified: Lever — filling form...');
      await handleLever(page, profile, resumePdfPath, coverLetter);

      // Now it will pause and ask for y/m/s before submitting!
      const { submitted, reason } = await autoSubmit(page);
      if (submitted) {
        return { status: 'Applied', rowId, resumePdfPath };
      }
      console.warn(`Could not auto-submit: ${reason}`);
      return { status: 'Needs Human Input', reason, rowId, resumePdfPath };

    } else {
      console.log('Target unidentified: No adapter available for this site yet.');
      return { status: 'Needs Human Input', reason: 'No ATS adapter matched', rowId, resumePdfPath };
    }

  } catch (err) {
    console.error(`Execution error on row #${rowId}:`, err.message);
    return { status: 'Failed', rowId, error: err.message, resumePdfPath };
  } finally {
    await browser.close();
  }
}

module.exports = { runApplicationPipeline };