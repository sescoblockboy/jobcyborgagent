const applyBtn = document.getElementById('applyBtn');
const statusBox = document.getElementById('statusBox');

function setStatus(text, isError = false) {
  statusBox.innerText = text;
  statusBox.style.color = isError ? '#ff7b72' : '#8b949e';
}

applyBtn.addEventListener('click', async () => {
  // Lock button into applying mode
  applyBtn.classList.add('applying');
  applyBtn.innerText = 'Applying...';
  applyBtn.disabled = true;
  setStatus("Connecting to page...");

  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });

  if (!tab || !tab.id) {
    applyBtn.classList.remove('applying');
    applyBtn.innerText = 'Auto-Apply';
    applyBtn.disabled = false;
    setStatus("No active tab found.", true);
    return;
  }

  // Ensure content script is injected safely
  try {
    await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      files: ['content.js']
    });
  } catch (err) {
    console.warn("Script injection check:", err);
  }

  // Fire run event to the content script
  chrome.tabs.sendMessage(tab.id, { action: "START_CYBORG" }, (response) => {
    if (chrome.runtime.lastError) {
      applyBtn.classList.remove('applying');
      applyBtn.innerText = 'Auto-Apply';
      applyBtn.disabled = false;
      setStatus("Refresh job page & click again.", true);
      return;
    }

    if (response && response.status === "started") {
      setStatus("Scraping JD & running n8n Brain...");
    }
  });
});

// Receive live status updates from content.js
chrome.runtime.onMessage.addListener((msg) => {
  if (msg.action === "STATUS_UPDATE") {
    setStatus(msg.text);

    if (msg.text.includes("filled") || msg.text.includes("Application filled")) {
      applyBtn.classList.remove('applying');
      applyBtn.innerText = 'Applied!';
      applyBtn.style.borderColor = '#00e676';
      applyBtn.disabled = false;
    } else if (msg.text.includes("Failed")) {
      applyBtn.classList.remove('applying');
      applyBtn.innerText = 'Retry';
      applyBtn.disabled = false;
    }
  }
});