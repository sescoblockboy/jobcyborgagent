// ============================================================
// JOB CYBORG
// BACKGROUND SERVICE WORKER
// Manifest V3
// ============================================================

"use strict";

const N8N_URL = "http://localhost:5678/webhook-test/cyborg-apply";

const LOG_PREFIX = "[Job Cyborg Background]";

// ============================================================
// LOGGING
// ============================================================

function log(...args) {
  console.log(LOG_PREFIX, ...args);
}

function warn(...args) {
  console.warn(LOG_PREFIX, ...args);
}

function error(...args) {
  console.error(LOG_PREFIX, ...args);
}

// ============================================================
// SAFE RESPONSE
// ============================================================

function safeSendResponse(sendResponse, data) {
  try {
    sendResponse(data);
  } catch (err) {
    warn("Could not send response:", err);
  }
}

// ============================================================
// FORWARD STATUS TO POPUP
// ============================================================

function forwardStatus(message) {
  try {
    chrome.runtime.sendMessage(message).catch?.(() => {});
  } catch (err) {
    // Popup may be closed. This is normal.
  }
}

// ============================================================
// N8N REQUEST
// ============================================================

async function callN8N(payload) {
  const controller = new AbortController();

  const timeout = setTimeout(() => {
    controller.abort();
  }, 60000);

  try {
    log("Sending request to n8n...");
    log("URL:", N8N_URL);

    const response = await fetch(N8N_URL, {
      method: "POST",

      headers: {
        "Content-Type": "application/json",
        "Accept": "application/json, text/plain, */*"
      },

      body: JSON.stringify(payload || {}),

      signal: controller.signal
    });

    const responseText = await response.text();

    log("n8n HTTP status:", response.status);

    if (!response.ok) {
      throw new Error(
        `n8n HTTP ${response.status} ${response.statusText}: ${responseText.slice(0, 1000)}`
      );
    }

    if (!responseText.trim()) {
      throw new Error(
        "n8n returned an empty response."
      );
    }

    let data;

    try {
      data = JSON.parse(responseText);
    } catch (jsonError) {
      // n8n sometimes returns plain text.
      data = responseText;
    }

    log("n8n response received.");

    return data;

  } catch (err) {

    if (err?.name === "AbortError") {
      throw new Error(
        "n8n request timed out after 60 seconds."
      );
    }

    throw err;

  } finally {
    clearTimeout(timeout);
  }
}

// ============================================================
// MESSAGE HANDLER
// ============================================================

chrome.runtime.onMessage.addListener(
  (request, sender, sendResponse) => {

    try {

      if (!request || typeof request !== "object") {

        safeSendResponse(sendResponse, {
          success: false,
          error: "Invalid extension message."
        });

        return false;
      }

      // ======================================================
      // STATUS UPDATE
      // ======================================================

      if (request.action === "STATUS_UPDATE") {

        log(
          sender?.tab?.id
            ? `Tab ${sender.tab.id}:`
            : "",
          request.text || ""
        );

        // Forward status to popup if it is open.
        forwardStatus({
          action: "STATUS_UPDATE",
          text: String(request.text || ""),
          type: request.type || "info"
        });

        return false;
      }

      // ======================================================
      // PING
      // ======================================================

      if (request.action === "PING") {

        safeSendResponse(sendResponse, {
          success: true,
          status: "background-ready"
        });

        return false;
      }

      // ======================================================
      // SEND TO N8N
      // ======================================================

      if (request.action === "SEND_TO_N8N") {

        log(
          "SEND_TO_N8N received from tab:",
          sender?.tab?.id
        );

        // Immediately tell content script that request was received.
        // This isn't the final n8n response.
        callN8N(request.payload)

          .then((data) => {

            log("n8n processing completed.");

            safeSendResponse(sendResponse, {
              success: true,
              data: data
            });

          })

          .catch((err) => {

            const message =
              err?.message ||
              String(err) ||
              "Unknown n8n error.";

            error("n8n request failed:", message);

            safeSendResponse(sendResponse, {
              success: false,
              error: message
            });

          });

        // VERY IMPORTANT:
        // The response happens asynchronously.
        return true;
      }

      // ======================================================
      // UNKNOWN ACTION
      // ======================================================

      safeSendResponse(sendResponse, {
        success: false,
        error: `Unknown action: ${request.action || "undefined"}`
      });

      return false;

    } catch (err) {

      error("Message handler crashed:", err);

      safeSendResponse(sendResponse, {
        success: false,
        error: err?.message || "Background message handler failed."
      });

      return false;
    }
  }
);

log("Service worker loaded.");