// ============================================================
// JOB CYBORG - HYBRID VISION AGENT (REACT-SAFE)
// ============================================================

if (!window.__JOB_CYBORG_CONTENT_LOADED__) {
  window.__JOB_CYBORG_CONTENT_LOADED__ = true;

  chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "PING") {
      sendResponse({ status: "ready" });
      return false;
    }
    if (request.action === "START_CYBORG") {
      sendResponse({ status: "started" });
      setTimeout(() => runCyborgAgent(), 0);
      return false;
    }
  });
}

function notify(text, type = "info") {
  console.log("[Job Cyborg]", text);
  try {
    chrome.runtime.sendMessage({ action: "STATUS_UPDATE", text, type });
  } catch (e) {}
}

// ==========================================================
// HYBRID FORM FILLER
// ==========================================================
function fillForm(aiData) {
  try {
    // Safely unwrap n8n arrays or nested data
    let data = aiData;
    if (typeof data === 'string') {
      try { data = JSON.parse(data); } catch(e) {}
    }
    if (Array.isArray(data)) data = data[0] || {};
    if (data.data) data = data.data; // Catch nested n8n data wrappers
    
    let filledCount = 0;

    const setInputValue = (selectors, value) => {
      if (!value || value === "SKIP" || value === "null") return false;
      
      for (const selector of selectors) {
        try {
          const el = document.querySelector(selector);
          if (el && !el.disabled && !el.readOnly) {
            
            let valToSet = String(value);
            if (el.tagName === 'SELECT') {
              const matchingOption = Array.from(el.options).find(opt => opt.text.toLowerCase().includes(valToSet.toLowerCase()));
              if (matchingOption) valToSet = matchingOption.value;
            }

            // REACT & ENTERPRISE BYPASS
            let nativeSetter = null;
            if (el.tagName === 'INPUT' || el.tagName === 'TEXTAREA') {
              nativeSetter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, "value")?.set || 
                             Object.getOwnPropertyDescriptor(window.HTMLTextAreaElement.prototype, "value")?.set;
            } else if (el.tagName === 'SELECT') {
              nativeSetter = Object.getOwnPropertyDescriptor(window.HTMLSelectElement.prototype, "value")?.set;
            }

            if (nativeSetter) {
              nativeSetter.call(el, valToSet);
            } else {
              el.value = valToSet;
            }

            el.dispatchEvent(new Event('input', { bubbles: true }));
            el.dispatchEvent(new Event('change', { bubbles: true }));
            console.log("[Job Cyborg] Filled:", selector);
            return true;
          }
        } catch (err) {}
      }
      return false;
    };

    const byLabel = (text) => {
      const labels = Array.from(document.querySelectorAll('label'));
      const target = labels.find(l => l.innerText.toLowerCase().includes(text.toLowerCase()));
      return (target && target.htmlFor) ? '#' + CSS.escape(target.htmlFor) : 'UNKNOWN_SELECTOR';
    };

    // 1. DYNAMIC LLM INJECTION (For custom questions)
    for (const [key, value] of Object.entries(data)) {
      // Only attempt to fill if the key looks like a valid CSS selector
      if (typeof key === 'string' && (key.startsWith('#') || key.startsWith('['))) {
        if (setInputValue([key], value)) filledCount++;
      }
    }

    // 2. IRONCLAD FALLBACKS (Guarantees core fields work on any platform)
    // NOTE: Update fallback values in your n8n workflow — no personal data is hardcoded here.
    if (setInputValue([byLabel("first name"), 'input[name="first_name"]', 'input[id*="first-name" i]', '#first_name'], data.first_name || data.firstName || "")) filledCount++;
    if (setInputValue([byLabel("last name"), 'input[name="last_name"]', 'input[id*="last-name" i]', '#last_name'], data.last_name || data.lastName || "")) filledCount++;
    if (setInputValue([byLabel("email"), 'input[name="email"]', 'input[type="email"]', '#email'], data.email || "")) filledCount++;
    if (setInputValue([byLabel("phone"), byLabel("mobile"), 'input[name="phone"]', 'input[type="tel"]', '#phone'], data.phone || "")) filledCount++;

    return filledCount;
  } catch (err) {
    console.error("[Job Cyborg] Form filling failed:", err);
    return 0;
  }
}

// ==========================================================
// AGENT EXECUTION
// ==========================================================
function runCyborgAgent() {
  notify("Reading form questions...");

  const visibleInputs = Array.from(document.querySelectorAll('input:not([type="hidden"]), select, textarea'));
  const formFields = visibleInputs.map(el => {
    let label = el.getAttribute('aria-label') || el.name || el.id;
    if (el.labels && el.labels.length > 0) label = el.labels[0].innerText;
    
    let identifier = '';
    if (el.id) identifier = `#${CSS.escape(el.id)}`;
    else if (el.name) identifier = `[name="${el.name}"]`;
    else if (el.getAttribute('data-automation-id')) identifier = `[data-automation-id="${el.getAttribute('data-automation-id')}"]`;
    
    return identifier ? { identifier, label: label.trim(), type: el.tagName } : null;
  }).filter(f => f !== null);

  const pageText = document.body.innerText.substring(0, 4000);

  notify("Sending to n8n Brain...");

  chrome.runtime.sendMessage(
    { action: "SEND_TO_N8N", payload: { url: window.location.href, job_description: pageText, form_fields: formFields } },
    (response) => {
      if (!response || !response.success) {
        notify("n8n failed. Check webhook.", "error");
        return;
      }
      notify("n8n generated answers. Typing...");
      const filled = fillForm(response.data);
      notify(filled > 0 ? `Application filled: ${filled} field(s).` : "No fields matched.", filled > 0 ? "success" : "error");
    }
  );
}