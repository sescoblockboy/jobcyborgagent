const { chromium } = require('playwright');
const path = require('path');
const fs = require('fs');

// We use a basic regex markdown parser to convert the AI's markdown into HTML
function parseMarkdownToHTML(markdown) {
    let html = markdown;
    html = html.replace(/^# (.*$)/gim, '<h1>$1</h1>');
    html = html.replace(/^## (.*$)/gim, '<h2>$1</h2>');
    html = html.replace(/^### (.*$)/gim, '<h3>$1</h3>');
    html = html.replace(/^\*\*([^*]+)\*\*/gim, '<strong>$1</strong>');
    html = html.replace(/^\*([^*]+)\*/gim, '<em>$1</em>');
    html = html.replace(/^- (.*$)/gim, '<ul><li>$1</li></ul>');
    // Fix adjacent lists
    html = html.replace(/<\/ul>\n<ul>/gim, '\n');
    html = html.replace(/\n$/gim, '<br />');
    return html;
}

async function generateResumePdf(resumeMarkdown, rowId) {
    const browser = await chromium.launch({ headless: true });
    // FIXED: Changed context.newPage() to browser.newPage()
    const page = await browser.newPage(); 
    
    const htmlContent = parseMarkdownToHTML(resumeMarkdown);

    // CSS injected to perfectly match "Yishak Namaga - Full Stack Web Developer - CV (2).pdf"
    const fullHtml = `
    <!DOCTYPE html>
    <html>
    <head>
        <style>
            @page { margin: 0.8in; }
            body {
                font-family: 'Helvetica Neue', Helvetica, Arial, sans-serif;
                color: #333;
                line-height: 1.5;
                font-size: 11pt;
            }
            h1 {
                text-align: center;
                font-size: 24pt;
                font-weight: 700;
                margin-bottom: 5px;
                text-transform: uppercase;
                color: #000;
            }
            h2 {
                text-align: center;
                font-size: 14pt;
                font-weight: 400;
                margin-top: 0;
                margin-bottom: 10px;
                color: #444;
            }
            p:first-of-type {
                text-align: center;
                font-size: 10pt;
                color: #555;
                margin-bottom: 20px;
            }
            h3 {
                font-size: 12pt;
                color: #000;
                text-transform: uppercase;
                border-bottom: 1px solid #ccc;
                padding-bottom: 3px;
                margin-top: 20px;
                margin-bottom: 10px;
            }
            strong {
                font-size: 11pt;
                color: #000;
            }
            em {
                font-style: italic;
                color: #555;
                display: block;
                margin-bottom: 5px;
            }
            ul {
                margin-top: 5px;
                margin-bottom: 15px;
                padding-left: 20px;
            }
            li {
                margin-bottom: 4px;
            }
        </style>
    </head>
    <body>
        ${htmlContent}
    </body>
    </html>
    `;

    await page.setContent(fullHtml, { waitUntil: 'networkidle' });
    
    // Ensure the resumes folder exists
    const dir = path.join(__dirname, 'resumes');
    if (!fs.existsSync(dir)){
        fs.mkdirSync(dir);
    }

    // FIXED: Removed the escaped backslashes from the template literal
    const pdfPath = path.join(dir, `resume_${rowId}.pdf`);
    await page.pdf({ path: pdfPath, format: 'A4', printBackground: true });
    
    await browser.close();
    return pdfPath;
}

module.exports = { generateResumePdf };