const { demographics } = require('../config');

async function handleGreenhouse(page, profile, resumePath, coverLetter) {
  console.log('Filling Greenhouse form...');

  const demo = demographics || {};

  // 1. Find and click the *visible* Apply button if on a landing page
  try {
    const applyBtns = page.locator('button:has-text("Apply"), a:has-text("Apply")');
    const count = await applyBtns.count();
    
    for (let i = 0; i < count; i++) {
      if (await applyBtns.nth(i).isVisible()) {
        console.log('Visible Apply button detected! Clicking it...');
        await applyBtns.nth(i).click();
        await page.waitForTimeout(3000); 
        break; 
      }
    }
  } catch (err) {
    // Ignore if not needed
  }

  // 2. Wait for the form to render
  await page.waitForSelector('#application_form, #apply_form, form', { timeout: 10000 });

  // 3. Fill standard text inputs
  await page.fill('input#first_name, input[name*="first_name"], input[placeholder*="First"]', profile.firstName).catch(() => {});
  await page.fill('input#last_name, input[name*="last_name"], input[placeholder*="Last"]', profile.lastName).catch(() => {});
  await page.fill('input#email, input[name*="email"], input[placeholder*="Email"]', profile.email).catch(() => {});
  await page.fill('input#phone, input[name*="phone"], input[placeholder*="Phone"]', profile.phone).catch(() => {});

  // 4. Location Autocomplete Handler
  try {
    const locationInput = await page.$('input#job_application_location, input[name*="location"], input[placeholder*="Location"]');
    if (locationInput) {
      await locationInput.click();
      await locationInput.fill(profile.location); 
      await page.waitForTimeout(1500); 
      await page.keyboard.press('ArrowDown');
      await page.keyboard.press('Enter'); 
    }
  } catch (err) {
    console.log('Location field filled via fallback.');
  }

  // 5. Intelligent Dropdown and Custom Question Handler
  try {
    const selects = await page.$$('select');
    for (const select of selects) {
      // Find the associated label text for each dropdown
      const labelElement = await select.$('xpath=./preceding-sibling::label | ./ancestor::div[contains(@class, "field")]//label | ./ancestor::div[contains(@class, "question")]//label');
      const labelText = labelElement ? (await labelElement.textContent()).toLowerCase() : '';
      
      if (labelText.includes('country') && demo.country) {
        await select.selectOption({ label: demo.country }).catch(() => {});
      } 
      else if ((labelText.includes('authorized to work in the united states') || labelText.includes('currently located in the us')) && demo.authorizedToWorkInUS) {
        await select.selectOption({ label: demo.authorizedToWorkInUS }).catch(() => {});
      } 
      else if (labelText.includes('relocate to the bay area') && demo.relocateToBayArea) {
        await select.selectOption({ label: demo.relocateToBayArea }).catch(() => {});
      } 
      else if (labelText.includes('gender') && !labelText.includes('identity') && demo.gender) {
        await select.selectOption({ label: demo.gender }).catch(() => {});
      } 
      else if (labelText.includes('race and ethnicity') && !labelText.includes('optional') && demo.raceEthnicity) {
        await select.selectOption({ label: demo.raceEthnicity }).catch(() => {});
      } 
      else if (labelText.includes('veteran status') && demo.veteranStatus) {
        await select.selectOption({ label: demo.veteranStatus }).catch(() => {});
      } 
      else if (labelText.includes('disability status') && demo.disabilityStatus) {
        await select.selectOption({ label: demo.disabilityStatus }).catch(() => {});
      }
    }
  } catch (err) {
    console.log('Custom question selector handled safely.');
  }

  // 6. Fill custom required text questions
  // NOTE: If a form has custom textarea questions, fill them via the
  // coverLetter field or extend this section for your use case.
  try {
    const textareas = await page.$$('textarea');
    for (const area of textareas) {
      const labelElement = await area.$('xpath=./preceding-sibling::label | ./ancestor::div[contains(@class, "field")]//label');
      const labelText = labelElement ? (await labelElement.textContent()).toLowerCase() : '';
      
      // Fill cover letter into any open textarea that looks like a free-text question
      if (coverLetter && labelText && (await area.inputValue()) === '') {
        await area.fill(coverLetter).catch(() => {});
      }
    }
  } catch (err) {
    console.log('Textarea questions handled.');
  }

  // 7. Fill professional links
  await page.fill('input[autocomplete="custom-question-linkedin"], input[name*="linkedin"], input[placeholder*="LinkedIn"]', profile.linkedin).catch(() => {});
  await page.fill('input[autocomplete="custom-question-website"], input[name*="website"], input[placeholder*="Website"]', profile.github).catch(() => {});

  // 8. Upload the PDF Resume
  const fileInput = await page.$('input[type="file"]');
  if (fileInput) {
    await fileInput.setInputFiles(resumePath).catch(() => console.log('Could not attach resume.'));
  }

  console.log('Greenhouse form successfully filled matching profile criteria.');
  return { readyToSubmit: true };
}

module.exports = { handleGreenhouse };