async function handleLever(page, profile, resumePath, coverLetter) {
  console.log('Filling Lever form...');
  await page.waitForSelector('.application-form', { timeout: 10000 });

  await page.fill('input[name="name"]', profile.fullName).catch(() => {});
  await page.fill('input[name="email"]', profile.email).catch(() => {});
  await page.fill('input[name="phone"]', profile.phone).catch(() => {});
  await page.fill('input[name="org"]', profile.location).catch(() => {});

  // Links
  await page.fill('input[name="urls[LinkedIn]"]', profile.linkedin).catch(() => {});
  await page.fill('input[name="urls[GitHub]"]', profile.github).catch(() => {});
  await page.fill('input[name="urls[Portfolio]"]', profile.website).catch(() => {});

  // Resume Upload
  const fileInput = await page.$('input[type="file"]');
  if (fileInput) {
    await fileInput.setInputFiles(resumePath).catch(() => console.log('Could not attach resume.'));
  }

  // Cover Letter
  if (coverLetter) {
    const commentsArea = await page.$('textarea[name="comments"]');
    if (commentsArea) await commentsArea.fill(coverLetter).catch(() => {});
  }

  return { readyToSubmit: true };
}

module.exports = { handleLever };