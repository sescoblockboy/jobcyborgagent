require('dotenv').config();
const express = require('express');
const { runApplicationPipeline } = require('./agent');

const app = express();
// Allow large payloads in case the LLM resume text is long
app.use(express.json({ limit: '10mb' }));

app.post('/apply', (req, res) => {
  const jobData = req.body;

  if (!jobData || !jobData.applyUrl) {
    return res.status(400).json({ error: 'Missing required field: applyUrl' });
  }

  // 1. Immediately acknowledge so n8n doesn't get a timeout error while you review the form
  res.status(202).json({ message: 'Application process queued locally', rowId: jobData.rowId });

  // 2. Process the browser automation asynchronously
  (async () => {
    const result = await runApplicationPipeline(jobData);

    // 3. Callback to n8n with the final status update.
    // Forward every field agent.js gave us, not just status/rowId — this is
    // what actually lands in the sheet columns downstream (resumePdfPath,
    // reason, error). Previously only rowId + status were sent, so the
    // resume path never reached n8n at all.
    try {
      await fetch(process.env.N8N_WEBHOOK_URL, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          rowId: result.rowId,
          status: result.status,
          resumePdfPath: result.resumePdfPath || null,
          reason: result.reason || null,
          error: result.error || null
        })
      });
      console.log(`Reported status "${result.status}" (resume: ${result.resumePdfPath || 'n/a'}) back to n8n webhook.`);
    } catch (e) {
      console.error('Could not reach n8n webhook:', e.message);
    }
  })();
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Local Job Agent is awake and listening on http://localhost:${PORT}`);
});