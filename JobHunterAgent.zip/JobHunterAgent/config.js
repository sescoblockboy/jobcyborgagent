module.exports = {
  profile: {
    firstName: "CHANGE_ME",
    lastName: "CHANGE_ME",
    fullName: "CHANGE_ME",
    email: "CHANGE_ME@example.com",
    phone: "+1234567890",            // International format
    location: "City, Country",
    linkedin: "https://www.linkedin.com/in/CHANGE_ME",
    github: "https://github.com/CHANGE_ME",
    workAuthorization: "Yes",
    requiresSponsorship: "No"
  },

  // Demographic / EEO fields (used by Greenhouse adapter)
  demographics: {
    country: "CHANGE_ME",                          // e.g. "United States"
    authorizedToWorkInUS: "No",                    // "Yes" or "No"
    relocateToBayArea: "Yes",                      // "Yes" or "No"
    gender: "CHANGE_ME",                           // e.g. "Male", "Female", "Decline to self-identify"
    raceEthnicity: "CHANGE_ME",                    // e.g. "White", "Black or African American", etc.
    veteranStatus: "I am not a protected veteran",
    disabilityStatus: "I do not wish to answer"
  }
};